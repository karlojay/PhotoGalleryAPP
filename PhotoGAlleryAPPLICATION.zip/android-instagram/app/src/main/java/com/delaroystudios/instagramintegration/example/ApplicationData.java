package com.delaroystudios.instagramintegration.example;

public class ApplicationData {
	public static final String CLIENT_ID = "49745eedbd964008acc78f16ddab8c0f";
	public static final String CLIENT_SECRET = "bed60a4f055e485da48508311de68feb";
	public static final String CALLBACK_URL = "http://www.karlovigilia.com";
}
